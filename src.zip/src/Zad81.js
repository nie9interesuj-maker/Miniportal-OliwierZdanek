import React from "react";
import FruitList from "./FruitList";
 
const App = () => {
  return (
      <FruitList />
  );
};
 
export default App;