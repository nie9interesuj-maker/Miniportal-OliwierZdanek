import React from "react";

const Header = ({ tytul }) => {
  return (
    <h1 style={{ textAlign: "center", marginBottom: "20px" }}>{tytul}</h1>
  );
};

export default Header;