import React from "react";

export default function Zad9() {
    const osoba = { Nazwisko: "Nowak", Miasto: "Radom" };
    return (
      <div>
        <p>Nazwisko: {osoba.Nazwisko}</p>
        <p>Nazwa miasta: {osoba.Miasto}</p>
      </div>
    );
  }
 
