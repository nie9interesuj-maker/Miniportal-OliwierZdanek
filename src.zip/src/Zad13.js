import React from "react";
 
export function Zadanie13({dynamicText}) {
    return(
        <div>
            {dynamicText}
        </div>
    )
}