import React from "react";
 
export function Zad12({color}) {
    return(
        <div style={{height:100, width:100, backgroundColor:color}}>
          witom
          
        </div>
    )
}
 